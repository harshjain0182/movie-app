# Movie API Backend

## Overview

This is a Node.js backend API service that provides movie data through RESTful endpoints. The application reads movie information from a CSV file (`movies.csv`) and serves it via an Express.js server. It supports fetching all movies and searching movies by name, director, writer, or cast.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
- **Express.js 5.x** serves as the web framework
- The application runs as a single `index.js` file with no modular structure
- CORS is enabled for cross-origin requests

### Data Storage
- **CSV file-based storage**: Movie data is loaded from `movies.csv` at startup
- Data is parsed once and stored in-memory as a JavaScript array
- No database is currently used - all data lives in memory after CSV parsing

### API Design
- RESTful API structure with `/api/movies` as the base path
- Endpoints:
  - `GET /` - Health check
  - `GET /api/movies` - Fetch all movies
  - `GET /api/movies/search?s=query` - Search movies by name, director, writer, or cast

### Key Design Decisions
1. **In-memory data storage**: Chosen for simplicity since the data source is a static CSV file. Trade-off is that data resets on server restart and doesn't scale for large datasets.
2. **Synchronous CSV loading at startup**: The CSV is fully parsed before the server handles requests, ensuring data availability.
3. **Case-insensitive search**: Search functionality converts all terms to lowercase for matching.

## External Dependencies

### NPM Packages
- **express** (v5.2.1) - Web server framework
- **cors** (v2.8.5) - Cross-origin resource sharing middleware
- **csv-parse** (v6.1.0) - CSV parsing library
- **uuid** (v13.0.0) - UUID generation (imported but not currently used in visible code)

### Data Sources
- **movies.csv** - Local CSV file containing movie data with columns including: name, director_name, writer_name, cast_name (and potentially others)

### External Services
- None currently integrated