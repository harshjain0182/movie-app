const express = require("express");
const cors = require("cors");
const fs = require("fs");
const { parse } = require("csv-parse");
const { v4: uuidv4 } = require("uuid");

const data = [];

fs.createReadStream("movies.csv")
  .pipe(
    parse({
      delimiter: ",",
      columns: true,
      ltrim: true,
      skip_empty_lines: true,
    }),
  )
  .on("data", function (row) {
    data.push(row);
  })
  .on("error", function (error) {
    console.log(error.message);
  })
  .on("end", function () {
    console.log("parsed csv data:", data.length, "rows");
  });
const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Hello World!");
  
});

app.get("/api/movies", (req, res) => {
  console.log("Fetching all movies");
  res.json(data);
});

app.get("/api/movies/search", (req, res) => {
  const query = req.query.s;
  if (!query) return res.json([]);
  
  const movie = data.filter(
    ({ name, director_name, writer_name, cast_name }) =>
      (name && name.toLowerCase().includes(query.toLowerCase())) ||
      (director_name && director_name.toLowerCase().includes(query.toLowerCase())) ||
      (writer_name && writer_name.toLowerCase().includes(query.toLowerCase())) ||
      (cast_name && cast_name.toLowerCase().includes(query.toLowerCase())),
  );
  res.json(movie);
});

app.get("/api/movies/genre", (req, res) => {
  const query = req.query.g;
  if (!query) return res.json([]);
  const movies = data.filter(({ genres }) => genres && genres.toLowerCase().includes(query.toLowerCase()));
  res.json(movies);
});

app.get("/api/movies/rating", (req, res) => {
  const query = req.query.i;
  const movies = data.filter(({ imdb_rating }) => parseFloat(imdb_rating) >= parseFloat(query));
  res.json(movies);
});

app.get("/api/movies/genres", (req, res) => {
  const allGenres = data.flatMap((movie) => movie.genres ? movie.genres.split(",").map(g => g.trim()) : []);
  const uniqueGenres = [...new Set(allGenres)];
  const genresList = uniqueGenres.map((genre) => ({ id: uuidv4(), genre }));
  res.json(genresList);
});

const PORT = 5000;

app.listen(PORT, "0.0.0.0", () => {
  console.log("Server running on port", PORT);
});
