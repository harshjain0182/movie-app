const express = require("express");
const cors = require("cors");
const fs = require("fs");
const { parse } = require("csv-parse");

const app = express();
app.use(cors());
app.use(express.json());

/* =======================
   LOAD CSV DATA ONCE
======================= */

const movies = [];

fs.createReadStream("movies.csv")
  .pipe(
    parse({
      delimiter: ",",
      columns: true,
      skip_empty_lines: true,
      trim: true,
    })
  )
  .on("data", (row) => {
    movies.push(row);
  })
  .on("end", () => {
    console.log(`✅ Movies loaded: ${movies.length}`);
  })
  .on("error", (err) => {
    console.error("CSV Error:", err.message);
  });

/* =======================
   HEALTH CHECK
======================= */

app.get("/", (req, res) => {
  res.send("Movie API running 🚀");
});

/* =======================
   MAIN MOVIES API
   (ALL FILTERS TOGETHER)
======================= */

app.get("/api/movies", (req, res) => {
  let result = [...movies];

  const { search, genre, rating } = req.query;

  // 🔍 SEARCH (name, director, writer, cast)
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(
      ({ name, director_name, writer_name, cast_name }) =>
        (name && name.toLowerCase().includes(q)) ||
        (director_name && director_name.toLowerCase().includes(q)) ||
        (writer_name && writer_name.toLowerCase().includes(q)) ||
        (cast_name && cast_name.toLowerCase().includes(q))
    );
  }

  // 🎭 GENRE FILTER
  if (genre) {
    const g = genre.toLowerCase();
    result = result.filter(
      (movie) =>
        movie.genres &&
        movie.genres.toLowerCase().includes(g)
    );
  }

  // ⭐ RATING FILTER
  if (rating) {
    const minRating = parseFloat(rating);
    result = result.filter(
      (movie) => parseFloat(movie.imdb_rating) >= minRating
    );
  }

  res.json(result);
});

/* =======================
   GENRES (FOR DROPDOWN)
======================= */

app.get("/api/movies/genres", (req, res) => {
  const genres = new Set();

  movies.forEach((movie) => {
    if (movie.genres) {
      movie.genres.split(",").forEach((g) => {
        genres.add(g.trim());
      });
    }
  });

  res.json([...genres]);
});

/* =======================
   RATINGS (FOR DROPDOWN)
======================= */

app.get("/api/movies/ratings", (req, res) => {
  const ratings = [
    ...new Set(
      movies
        .map((movie) => parseFloat(movie.imdb_rating))
        .filter((r) => !isNaN(r))
    ),
  ].sort((a, b) => b - a);

  res.json(ratings);
});

/* =======================
   SERVER START
======================= */

const PORT = 5000;

app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
